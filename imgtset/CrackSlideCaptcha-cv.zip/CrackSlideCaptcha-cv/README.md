# CrackSlideCaptcha

Crack Slide Captcha
